# D3portfolio
Projects, practice, and portfolio
